// Copyright 2019-2022 Chris Garnier (The Tool Shed). All Rights Reserved.

#include "AssetsCleanerCommands.h"

#define LOCTEXT_NAMESPACE "FAssetsCleanerModule"

void FAssetsCleanerCommands::RegisterCommands()
{
}

#undef LOCTEXT_NAMESPACE
