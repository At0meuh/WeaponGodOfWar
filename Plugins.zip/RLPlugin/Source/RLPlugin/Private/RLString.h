#pragma once

#define Version_Error_Message       "The current procedure has come to a stop because auto-setup is not support for this version of CC / iClone. Please update to the appropriate version."
#define Version_Not_Suitable        "Auto-setup is not support for this version of CC / iClone and some issues may occur as a result. Please update to the appropriate version."